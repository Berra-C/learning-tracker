/* Shared account adapter. Must be checked against actual Productivity App app-api before production. */
LT.cloud = (() => {
  const config=()=>globalThis.LT_CLOUD_CONFIG||{};
  function configured(){return /^https:\/\//.test(config().apiUrl||'')}
  async function request(action,fields={},session=null){if(!configured())throw Error('Bulut bağlantısı yapılandırılmadı');const cfg=config();const body={action,...fields};if(session)body[cfg.sessionField||'sessionToken']=session;const headers={'Content-Type':'application/json'};if(cfg.anonKey){headers.apikey=cfg.anonKey;headers.Authorization=`Bearer ${cfg.anonKey}`;}
    const ctrl=new AbortController();const timeout=setTimeout(()=>ctrl.abort(),16000);let res;try{res=await fetch(cfg.apiUrl,{method:'POST',headers,body:JSON.stringify(body),signal:ctrl.signal})}catch(e){throw Error('Bağlantı hatası: '+e.message)}finally{clearTimeout(timeout)}let data;try{data=await res.json()}catch{throw Error('Sunucu geçerli JSON döndürmedi')}
    if(!res.ok||data?.error||data?.success===false){const err=new Error(typeof data?.error==='string'?data.error:(data?.message||`Sunucu hatası (${res.status})`));err.status=res.status;err.code=data?.code||data?.error_code;err.payload=data;throw err}return data?.data&&typeof data.data==='object'?data.data:data;
  }
  const SESSION_KEY='test_cloud_session',USERNAME_KEY='test_cloud_username',ACCOUNT_KEY='test_cloud_account_id';
  function getSession(){return sessionStorage.getItem(SESSION_KEY)||localStorage.getItem(SESSION_KEY)||null}
  function storeSession(result,remember){const target=remember?localStorage:sessionStorage;const other=remember?sessionStorage:localStorage;other.removeItem(SESSION_KEY);other.removeItem(USERNAME_KEY);other.removeItem(ACCOUNT_KEY);target.setItem(SESSION_KEY,result.token);target.setItem(USERNAME_KEY,result.username);target.setItem(ACCOUNT_KEY,String(result.accountId));}
  function clearSession(){for(const store of [localStorage,sessionStorage])for(const key of [SESSION_KEY,USERNAME_KEY,ACCOUNT_KEY])store.removeItem(key)}
  function identity(payload){const account=payload?.account||payload?.user||payload;const token=payload?.sessionToken||payload?.session_token||payload?.token||payload?.session?.token||getSession();const accountId=account?.id||account?.account_id||payload?.accountId||payload?.account_id;const username=account?.username||payload?.username;return{token,accountId,username,magicPhrase:payload?.magicPhrase||payload?.magic_phrase||payload?.credentials?.magicPhrase};}
  async function signup(accessCode){return request('signup',{accessCode})}
  async function login(username,magicPhrase,accessCode,remember){const out=identity(await request('login',{username,magicPhrase,accessCode,rememberDevice:remember}));if(!out.token||!out.accountId||!out.username)throw Error('Giriş yanıtı mevcut backend ile eşleşmiyor; cloud.js adaptörünü kontrol edin');storeSession(out,remember);return out;}
  async function me(){const token=getSession();if(!token)return null;try{const out=identity(await request('me',{},token));if(!out.accountId)throw Error('Me yanıtında hesap kimliği eksik');return out}catch(e){if([401,403].includes(e.status))clearSession();throw e}}
  async function logout(){const token=getSession();try{if(token)await request('logout',{},token)}finally{clearSession()}}
  function pull(){return request('learning-tracker-sync-pull',{},getSession())}
  function push(state,expectedRevision){return request('learning-tracker-sync-push',{state,expectedRevision},getSession())}
  function listDevices(){return request('list-devices',{},getSession())}
  function revokeOthers(){return request('revoke-other-devices',{},getSession())}
  return {configured,request,getSession,clearSession,identity,signup,login,me,logout,pull,push,listDevices,revokeOthers};
})();
