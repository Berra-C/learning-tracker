/* Learning Tracker domain model — source of truth, no fabricated sample records. */
globalThis.LT = globalThis.LT || {};
LT.core = (() => {
  const SCHEMA = 1;
  const uid = () => globalThis.crypto?.randomUUID?.() || `lt_${Date.now()}_${Math.random().toString(36).slice(2)}`;
  const now = () => new Date().toISOString();
  const isoDay = (d) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  function dateOf(s) { if(!/^\d{4}-\d{2}-\d{2}$/.test(s||'')) throw Error('Geçersiz tarih'); const [y,m,d]=s.split('-').map(Number);const dt=new Date(y,m-1,d,12);if(isoDay(dt)!==s)throw Error('Geçersiz takvim tarihi');return dt; }
  function monday(value=new Date()) { const d=typeof value==='string'?dateOf(value):new Date(value);d.setHours(12,0,0,0); d.setDate(d.getDate()-(d.getDay()+6)%7);return isoDay(d); }
  function addDays(value,days){let d=typeof value==='string'?dateOf(value):new Date(value);d.setDate(d.getDate()+days);return isoDay(d);}
  function weekEnd(week){return addDays(week,6)}
  function weekEndInstant(week) { // next Monday local midnight, exclusive
    const d=dateOf(addDays(week,7));d.setHours(0,0,0,0);return d.getTime();
  }
  const defaults = () => ({schemaVersion:SCHEMA,courses:[],resources:[],nodes:[],progress:[],events:[],assignments:[],reviews:[],weekNotes:[],settings:{planStartDate:monday(),planEndDate:addDays(monday(),41),showHighlights:false, mappings:{}},updatedAt:now()});
  const live = x => !x.deletedAt;
  const byId = (state,key,id)=>state[key].find(x=>x.id===id && live(x));
  const courses = state=>state.courses.filter(live);
  const resources = (s,courseId)=>s.resources.filter(r=>live(r)&&r.courseId===courseId);
  const nodes = (s,resourceId)=>s.nodes.filter(n=>live(n)&&n.resourceId===resourceId).sort((a,b)=>a.order-b.order||a.id.localeCompare(b.id));
  function tree(s,resourceId) {const ns=nodes(s,resourceId),lookup=new Map(ns.map(n=>[n.id,{...n,children:[]}]));const roots=[];for(const n of ns){const node=lookup.get(n.id),parent=lookup.get(n.parentId);if(parent && parent.id!==node.id)parent.children.push(node);else roots.push(node);}return roots;}
  function leaves(s,resourceId){ const ns=nodes(s,resourceId);const parents=new Set(ns.map(n=>n.parentId).filter(Boolean));return ns.filter(n=>n.kind!=='group'&&!parents.has(n.id)); }
  function courseLeaves(s,courseId){return resources(s,courseId).flatMap(r=>leaves(s,r.id));}
  function progressFor(s,nodeId){return s.progress.find(p=>p.nodeId===nodeId&&!p.deletedAt)||null;}
  function status(s,nodeId){return progressFor(s,nodeId)?.status||'notstarted'}
  function counts(s,list){const done=list.filter(n=>status(s,n.id)==='completed').length;return{done,total:list.length,pct:list.length?Math.round(done/list.length*100):0}}
  const resourceStats=(s,id)=>counts(s,leaves(s,id));
  const courseStats=(s,id)=>counts(s,courseLeaves(s,id));
  const totalStats=s=>counts(s,courses(s).flatMap(c=>courseLeaves(s,c.id)));
  function descendants(s,nodeId){const n=byId(s,'nodes',nodeId);if(!n)return[];const ns=nodes(s,n.resourceId);const parents=new Map();ns.forEach(x=>{if(!parents.has(x.parentId))parents.set(x.parentId,[]);parents.get(x.parentId).push(x)});const out=[],visited=new Set();function walk(id){for(const x of parents.get(id)||[]){if(visited.has(x.id))continue;visited.add(x.id);if(x.kind!=='group'&&!(parents.get(x.id)||[]).length)out.push(x);walk(x.id)}}walk(nodeId);if(n.kind!=='group' && !((parents.get(nodeId)||[]).length))out.unshift(n);return out;}
  function addCourse(s,name,category='school',color='#159e89'){name=String(name||'').trim();if(!name)throw Error('Ders adını girin');if(!['school','independent'].includes(category))throw Error('Geçersiz kategori');const c={id:uid(),name,category,color,createdAt:now(),updatedAt:now(),archivedAt:null,deletedAt:null};s.courses.push(c);touch(s);return c;}
  function addResource(s,courseId,title,type='book',sourceUrl=''){if(!byId(s,'courses',courseId))throw Error('Ders bulunamadı');title=String(title||'').trim();if(!title)throw Error('Kaynak adı gerekli');if(!['book','video','website','other'].includes(type))throw Error('Geçersiz kaynak türü');if(sourceUrl&&!/^https?:\/\//i.test(sourceUrl))throw Error('Bağlantı http veya https ile başlamalı');const r={id:uid(),courseId,title,type,sourceUrl,sourceAccess:null,createdAt:now(),updatedAt:now(),archivedAt:null,deletedAt:null};s.resources.push(r);touch(s);return r;}
  function touch(s){s.updatedAt=now();}
  function editRecord(s,key,id,changes,allowed){const rec=byId(s,key,id);if(!rec)throw Error('Kayıt bulunamadı');for(const k of allowed)if(Object.hasOwn(changes,k))rec[k]=changes[k];rec.updatedAt=now();touch(s);return rec;}
  function softDelete(s,key,id){const rec=byId(s,key,id);if(!rec)return;rec.deletedAt=now();rec.updatedAt=rec.deletedAt;
    if(key==='courses')resources(s,id).forEach(r=>softDelete(s,'resources',r.id));
    if(key==='resources')nodes(s,id).forEach(n=>softDelete(s,'nodes',n.id));
    if(key==='nodes'){for(const child of s.nodes.filter(n=>n.parentId===id&&!n.deletedAt))softDelete(s,'nodes',child.id);const p=progressFor(s,id);if(p){p.deletedAt=now();p.updatedAt=p.deletedAt}for(const a of s.assignments.filter(a=>a.nodeId===id&&a.status==='active')){a.status='removed';a.closedAt=now();a.updatedAt=a.closedAt;}}
    touch(s);
  }
  function setStatus(s,nodeId,newStatus,time=now()) {const node=byId(s,'nodes',nodeId);if(!node)throw Error('Konu bulunamadı');if(!['notstarted','progress','completed'].includes(newStatus))throw Error('Geçersiz durum');if(!leaves(s,node.resourceId).some(n=>n.id===nodeId))throw Error('Yalnızca en alt düzey konular tamamlanabilir');const old=status(s,nodeId);if(old===newStatus)return;let p=progressFor(s,nodeId);if(!p){p={id:nodeId,nodeId,status:newStatus,completedAt:newStatus==='completed'?time:null,updatedAt:time,deletedAt:null};s.progress.push(p)}else{p.status=newStatus;p.completedAt=newStatus==='completed'?time:null;p.updatedAt=time;}s.events.push({id:uid(),kind:'progress',nodeId,from:old,to:newStatus,at:time});touch(s);}
  function setDescendants(s,parentId,newStatus){for(const n of descendants(s,parentId))setStatus(s,n.id,newStatus)}
  function progressAt(s,nodeId,cutoff){const entries=s.events.filter(e=>e.kind==='progress'&&e.nodeId===nodeId&&new Date(e.at).getTime()<cutoff).sort((a,b)=>a.at.localeCompare(b.at)||a.id.localeCompare(b.id));return entries.at(-1)?.to||'notstarted';}
  function resourceStatsAt(s,resourceId,cutoff){
    const resource=s.resources.find(r=>r.id===resourceId);
    if(!resource||new Date(resource.createdAt).getTime()>=cutoff||(resource.deletedAt&&new Date(resource.deletedAt).getTime()<cutoff))return {done:0,total:0,pct:0};
    const existing=s.nodes.filter(n=>n.resourceId===resourceId&&new Date(n.createdAt).getTime()<cutoff&&(!n.deletedAt||new Date(n.deletedAt).getTime()>=cutoff));
    const parents=new Set(existing.map(n=>n.parentId).filter(Boolean));
    const leavesAt=existing.filter(n=>n.kind!=='group'&&!parents.has(n.id));
    const done=leavesAt.filter(n=>progressAt(s,n.id,cutoff)==='completed').length;
    return {done,total:leavesAt.length,pct:leavesAt.length?Math.round(done/leavesAt.length*100):0};
  }
  function courseStatsAt(s,courseId,cutoff){const rs=s.resources.filter(r=>r.courseId===courseId).map(r=>resourceStatsAt(s,r.id,cutoff));const done=rs.reduce((v,x)=>v+x.done,0),total=rs.reduce((v,x)=>v+x.total,0);return {done,total,pct:total?Math.round(done/total*100):0}}
  function validateState(s){if(!s||typeof s!=='object'||Array.isArray(s)||s.schemaVersion!==SCHEMA)throw Error('Yedek sürümü desteklenmiyor');for(const key of ['courses','resources','nodes','progress','events','assignments','reviews','weekNotes']){if(!Array.isArray(s[key])||s[key].length>150000)throw Error(`${key}: geçersiz kayıt listesi`);for(const rec of s[key])if(!rec||typeof rec!=='object'||typeof rec.id!=='string'||rec.id.length>180)throw Error(`${key}: geçersiz kayıt kimliği`);}if(!s.settings||typeof s.settings!=='object')throw Error('Ayarlar eksik');if(JSON.stringify(s).length>8_000_000)throw Error('Yedek 8 MB sınırını aşıyor');for(const key of ['courses','resources','nodes','progress','assignments']){const ids=new Set();for(const rec of s[key]){if(ids.has(rec.id))throw Error(`${key}: yinelenen kimlik`);ids.add(rec.id)}}for(const n of s.nodes){if(!['group','topic','quiz','test'].includes(n.kind)||typeof n.title!=='string'||!n.title.trim())throw Error('Geçersiz konu kaydı')}
    for(const co of s.courses)if(typeof co.name!=='string'||!co.name.trim()||co.name.length>120||!['school','independent'].includes(co.category))throw Error('Geçersiz ders kaydı');
    for(const r of s.resources)if(typeof r.title!=='string'||!r.title.trim()||r.title.length>200||!['book','video','website','other'].includes(r.type)||typeof r.courseId!=='string'||(r.sourceUrl&&!/^https?:\/\//i.test(r.sourceUrl)))throw Error('Geçersiz kaynak kaydı');
    for(const pr of s.progress)if(typeof pr.nodeId!=='string'||!['notstarted','progress','completed'].includes(pr.status))throw Error('Geçersiz ilerleme durumu');
    const activeIds=new Set();for(const a of s.assignments){if(typeof a.nodeId!=='string'||!['active','moved','removed'].includes(a.status)||typeof a.weekStart!=='string'||monday(a.weekStart)!==a.weekStart)throw Error('Geçersiz haftalık atama');if(a.status==='active'&&!a.deletedAt){if(activeIds.has(a.nodeId))throw Error('Aynı konuya iki aktif hafta atanmış');activeIds.add(a.nodeId)}}
    for(const e of s.events)if(!['progress','reschedule','unassign'].includes(e.kind)||typeof e.at!=='string'||!Number.isFinite(Date.parse(e.at)))throw Error('Geçersiz olay kaydı');
    for(const review of s.reviews)if(typeof review.weekStart!=='string'||monday(review.weekStart)!==review.weekStart||!Number.isInteger(review.plannedCount)||!Number.isInteger(review.completedCount)||review.completedCount>review.plannedCount||!Array.isArray(review.unfinishedNodeIds))throw Error('Geçersiz hafta değerlendirmesi');
    for(const n of s.weekNotes)if(typeof n.text!=='string'||n.text.length>10000)throw Error('Geçersiz hafta notu');
    for(const key of ['planStartDate','planEndDate'])dateOf(s.settings[key]);
    return true;}
  return {SCHEMA,uid,now,isoDay,dateOf,monday,addDays,weekEnd,weekEndInstant,defaults,live,byId,courses,resources,nodes,tree,leaves,courseLeaves,progressFor,status,counts,resourceStats,courseStats,totalStats,descendants,addCourse,addResource,editRecord,softDelete,setStatus,setDescendants,progressAt,resourceStatsAt,courseStatsAt,validateState,touch};
})();
