/* AI uses an external chatbot. Importer neither fetches nor fabricates source contents. */
LT.importer = (() => {
  const {uid,now,touch,nodes,byId,softDelete} = LT.core;
  const MAX_DEPTH = 32, MAX_NODES=15000;
  function parse(input) {
    if(typeof input!=='string'||input.length>4_000_000)throw Error('JSON metni 4 MB sınırını aşıyor');
    let source=input.trim();if(source.startsWith('```'))source=source.replace(/^```(?:json)?\s*/i,'').replace(/\s*```$/,'');
    let obj;try{obj=JSON.parse(source)}catch(e){throw Error('Geçersiz JSON: '+e.message)}
    if(!obj||Array.isArray(obj)||typeof obj!=='object')throw Error('Kök veri nesne olmalı');
    if(obj.schema_version!==1)throw Error('Desteklenmeyen schema_version (1 olmalı)');
    if(typeof obj.resource_title!=='string'||!obj.resource_title.trim())throw Error('resource_title boş olamaz');
    if(!['full','partial','unavailable'].includes(obj.source_access))throw Error('source_access: full, partial veya unavailable olmalı');
    if(!Array.isArray(obj.notes)||obj.notes.some(n=>typeof n!=='string'))throw Error('notes metin dizisi olmalı');
    if(!Array.isArray(obj.structure))throw Error('structure dizisi bulunamadı');
    if(obj.source_access==='unavailable'&&obj.structure.length)throw Error('Erişilemeyen kaynak boş yapıyla gelmeli');
    let count=0;const walk=(input,depth)=>{if(depth>MAX_DEPTH)throw Error('İçerik hiyerarşisi fazla derin');if(!Array.isArray(input))throw Error('children bir dizi olmalı');return input.map((node)=>{count++;if(count>MAX_NODES)throw Error('Çok fazla konu');if(!node||Array.isArray(node)||typeof node!=='object'||typeof node.title!=='string'||!node.title.trim()||node.title.length>500||!Array.isArray(node.children))throw Error('Her konu title ve children içermeli');return{_key:uid(),title:node.title.trim(),kind:node.children.length?'group':'topic',children:walk(node.children,depth+1)}})};
    return {schema_version:1,resource_title:obj.resource_title.trim(),source_access:obj.source_access,notes:obj.notes.slice(0,50),structure:walk(obj.structure,0)};
  }
  function flatten(preview, resourceId) {const out=[];function walk(rows,parentId=null){rows.forEach((x,order)=>{const n={id:x.id||uid(),resourceId,parentId,title:x.title.trim(),kind:x.children.length?'group':(x.kind||'topic'),order,createdAt:x.createdAt||now(),updatedAt:now(),deletedAt:null};out.push(n);walk(x.children,n.id)})}walk(preview);return out;}
  function existingPreview(s,resourceId){const convert = ns=>ns.map(n=>({id:n.id,_key:n.id,title:n.title,kind:n.kind,createdAt:n.createdAt,children:convert(n.children)}));return convert(LT.core.tree(s,resourceId));}
  function apply(s, resourceId, preview, sourceAccess) {
    const resource=byId(s,'resources',resourceId);if(!resource)throw Error('Kaynak bulunamadı');
    const newNodes=flatten(preview,resourceId);if(newNodes.length>MAX_NODES)throw Error('Konu limiti aşıldı');
    const ids=new Set();for(const n of newNodes){if(!n.title||ids.has(n.id))throw Error('Konu kimlikleri geçersiz');ids.add(n.id)}
    const current=nodes(s,resourceId);
    for(const old of current)if(!ids.has(old.id))softDelete(s,'nodes',old.id);
    for(const n of newNodes){const old=s.nodes.find(x=>x.id===n.id);if(old && old.resourceId===resourceId){old.parentId=n.parentId;old.title=n.title;old.kind=n.kind;old.order=n.order;old.updatedAt=now();old.deletedAt=null}else if(old){throw Error('Başka kaynağa ait konu kimliği kullanılamaz')}else s.nodes.push(n)}
    resource.sourceAccess=sourceAccess||resource.sourceAccess;resource.updatedAt=now();touch(s);return newNodes.length;
  }
  function createPrompt(resource,courseName) {return `You are an accurate educational resource structure extractor. Analyze only the supplied source material.\n\nResource: ${resource.title}\nCourse: ${courseName||''}\nType: ${resource.type}\nSource URL (if supplied): ${resource.sourceUrl||'none'}\n\nPreserve actual chapter, unit, module, lesson, section and topic order and nesting at any depth. Do not summarize, do not invent material, do not guess missing chapters, and do not add general subject knowledge. Exclude unrelated site navigation and advertisements. For video resources use the actual module and lesson structure. If the material is partly accessible, state limitations in notes. If inaccessible, use source_access "unavailable" and an empty structure. Do not invent completion states or progress. Return ONLY valid JSON, no Markdown fences or explanations. Use exactly this schema (recursive children):\n{\n  "schema_version": 1,\n  "resource_title": ${JSON.stringify(resource.title)},\n  "source_access": "full",\n  "notes": [],\n  "structure": [\n    {"title":"Actual chapter or unit title", "children":[{"title":"Actual topic title","children":[]}]}\n  ]\n}\nThe schema above is an EXAMPLE only; replace its chapter and topic with actually verified source contents. If unavailable return no example topics.`;}
  return {parse,flatten,existingPreview,apply,createPrompt,MAX_DEPTH,MAX_NODES};
})();
