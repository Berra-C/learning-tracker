/* Weekly assignments are eventful: moving never destroys a prior week's record. */
LT.planning = (() => {
  const c=LT.core;
  function active(s,nodeId){return s.assignments.find(a=>a.nodeId===nodeId&&a.status==='active'&&!a.deletedAt)||null;}
  function assign(s,nodeId,weekStart){weekStart=c.monday(weekStart);if(c.weekEndInstant(weekStart)<=Date.now())throw Error('Kapanmış bir haftaya yeni atama yapılamaz');const n=c.byId(s,'nodes',nodeId);if(!n||!c.leaves(s,n.resourceId).find(x=>x.id===nodeId))throw Error('Planlanabilir konu bulunamadı');const prior=active(s,nodeId);if(prior?.weekStart===weekStart)return prior;const at=c.now();if(prior){prior.status='moved';prior.closedAt=at;prior.updatedAt=at;s.events.push({id:c.uid(),kind:'reschedule',nodeId,from:prior.weekStart,to:weekStart,at});}
    const a={id:c.uid(),nodeId,weekStart,status:'active',createdAt:at,closedAt:null,updatedAt:at,deletedAt:null};s.assignments.push(a);c.touch(s);return a;}
  function remove(s,nodeId){const prior=active(s,nodeId);if(!prior)return;prior.status='removed';prior.closedAt=c.now();prior.updatedAt=prior.closedAt;s.events.push({id:c.uid(),kind:'unassign',nodeId,from:prior.weekStart,to:null,at:prior.closedAt});c.touch(s)}
  const assignmentAt=(a,cutoff)=>new Date(a.createdAt).getTime()<cutoff&&(!a.closedAt||new Date(a.closedAt).getTime()>=cutoff);
  function rows(s,weekStart, historical=false){weekStart=c.monday(weekStart);const cutoff=c.weekEndInstant(weekStart);const isPast=cutoff<=Date.now();const snapshot=s.reviews.find(r=>r.weekStart===weekStart);
    if(historical&&isPast&&snapshot) return snapshot;
    const eligible=s.assignments.filter(a=>a.weekStart===weekStart&&(isPast?assignmentAt(a,cutoff):a.status==='active'));
    const list=eligible.map(a=>{const n=c.byId(s,'nodes',a.nodeId)||s.nodes.find(n=>n.id===a.nodeId);const r=n&&s.resources.find(r=>r.id===n.resourceId);const course=r&&s.courses.find(co=>co.id===r.courseId);const complete=isPast?c.progressAt(s,a.nodeId,cutoff)==='completed':c.status(s,a.nodeId)==='completed';return{assignment:a,node:n,resource:r,course,complete}}).filter(x=>x.node);
    const done=list.filter(x=>x.complete).length;return{weekStart,weekEnd:c.weekEnd(weekStart),plannedCount:list.length,completedCount:done,completionPercentage:list.length?Math.round(done/list.length*100):0,unfinishedNodeIds:list.filter(x=>!x.complete).map(x=>x.node.id),rows:list};
  }
  function snapshotWeeks(s) {
    const dates=[...new Set(s.assignments.map(a=>a.weekStart))].filter(week=>c.weekEndInstant(week)<=Date.now()).sort();
    let changed=false;
    for(const week of dates){if(s.reviews.some(r=>r.weekStart===week))continue;const r=rows(s,week);if(!r.plannedCount)continue;
      const review={id:c.uid(),weekStart:week,weekEnd:r.weekEnd,plannedCount:r.plannedCount,completedCount:r.completedCount,completionPercentage:r.completionPercentage,unfinishedNodeIds:r.unfinishedNodeIds,resolvedNodeIds:[],assignmentIds:r.rows.map(x=>x.assignment.id),status:r.unfinishedNodeIds.length?'pending':'handled',reviewedAt:null,createdAt:c.now(),updatedAt:c.now(),deletedAt:null};s.reviews.push(review);changed=true;}
    if(changed)c.touch(s);return changed;
  }
  function pendingReviews(s){return s.reviews.filter(r=>r.status==='pending'||r.status==='deferred').sort((a,b)=>a.weekStart.localeCompare(b.weekStart));}
  function editReview(s,id,status){const r=s.reviews.find(r=>r.id===id);if(!r||!['pending','deferred','handled','dismissed'].includes(status))throw Error('Değerlendirme bulunamadı');r.status=status;r.reviewedAt=status==='handled'||status==='dismissed'?c.now():null;r.updatedAt=c.now();c.touch(s);}
  function weeks(s){const a=c.monday(s.settings.planStartDate),b=c.monday(s.settings.planEndDate);if(b<a)throw Error('Bitiş başlangıçtan önce');const result=[];for(let w=a;w<=b&&result.length<105;w=c.addDays(w,7))result.push(w);return result;}
  function updateRange(s,start,end){const a=c.monday(start),b=c.monday(end);if(b<a)throw Error('Bitiş başlangıçtan önce olmalı');if((c.dateOf(b)-c.dateOf(a))/86400000>730)throw Error('Takvim en fazla iki yıl olabilir');s.settings.planStartDate=start;s.settings.planEndDate=end;c.touch(s)}
  return {active,assign,remove,rows,snapshotWeeks,pendingReviews,editReview,weeks,updateRange,assignmentAt};
})();
