/* Explicit optimistic concurrency and three-way merge; never silently overwrite concurrent edits. */
LT.sync = (() => {
  const COLLECTIONS=['courses','resources','nodes','progress','events','assignments','reviews','weekNotes'];
  const clone=x=>JSON.parse(JSON.stringify(x));
  const same=(a,b)=>JSON.stringify(a??null)===JSON.stringify(b??null);
  function merge(base,local,remote){LT.core.validateState(local);LT.core.validateState(remote);if(base)LT.core.validateState(base);const result=clone(remote),conflicts=[];
    for(const key of COLLECTIONS){const b=new Map((base?.[key]||[]).map(x=>[x.id,x])),l=new Map(local[key].map(x=>[x.id,x])),r=new Map(remote[key].map(x=>[x.id,x]));const ids=new Set([...b.keys(),...l.keys(),...r.keys()]);const out=[];for(const id of ids){const bv=b.get(id),lv=l.get(id),rv=r.get(id);let winner;if(same(lv,bv))winner=rv;else if(same(rv,bv))winner=lv;else if(same(lv,rv))winner=lv;else {conflicts.push({collection:key,id,local:lv||null,remote:rv||null});winner=rv;}if(winner)out.push(clone(winner));}result[key]=out;}
    const bs=base?.settings,ls=local.settings,rs=remote.settings;
    if(same(ls,bs))result.settings=clone(rs);else if(same(rs,bs)||same(ls,rs))result.settings=clone(ls);else {conflicts.push({collection:'settings',id:'settings',local:ls,remote:rs});result.settings=clone(rs)}
    // Two devices can add DIFFERENT assignment records for the same node ID.
    // Detect the semantic collision instead of silently keeping two active weeks.
    const activeByNode=new Map();
    for(const a of result.assignments.filter(x=>x.status==='active'&&!x.deletedAt)){
      if(!activeByNode.has(a.nodeId))activeByNode.set(a.nodeId,[]);
      activeByNode.get(a.nodeId).push(a);
    }
    for(const [nodeId,assignments] of activeByNode){
      if(assignments.length<2)continue;
      const localActive=local.assignments.find(x=>x.nodeId===nodeId&&x.status==='active');
      const remoteActive=remote.assignments.find(x=>x.nodeId===nodeId&&x.status==='active');
      conflicts.push({collection:'assignment-collision',id:nodeId,local:localActive||assignments[0],remote:remoteActive||assignments[1]});
    }
    return {state:result,conflicts};
  }
  function resolve(merged,conflicts,choice){const out=clone(merged);for(const issue of conflicts){const chosen=choice==='local'?issue.local:issue.remote;
    if(issue.collection==='settings'){out.settings=clone(chosen);continue}
    if(issue.collection==='assignment-collision'){
      const at=new Date().toISOString();
      for(const a of out.assignments.filter(x=>x.nodeId===issue.id&&x.status==='active'&&x.id!==chosen.id)){
        a.status='moved';a.closedAt=at;a.updatedAt=at;
        out.events.push({id:LT.core.uid(),kind:'reschedule',nodeId:issue.id,from:a.weekStart,to:chosen.weekStart,at});
      }
      continue;
    }
    out[issue.collection]=out[issue.collection].filter(x=>x.id!==issue.id);
    if(chosen)out[issue.collection].push(clone(chosen));
  }LT.core.validateState(out);return out;}
  function useCache(key){let record;try{record=JSON.parse(localStorage.getItem(key)||'null')}catch{return null}try{if(record?.state)LT.core.validateState(record.state);else return null;return record}catch{return null}}
  function writeCache(key,state,revision,baseState){try{localStorage.setItem(key,JSON.stringify({state,revision,baseState}))}catch(e){throw Error('Yerel depolama dolu: JSON yedeği alın')};}
  return {COLLECTIONS,clone,same,merge,resolve,useCache,writeCache};
})();
