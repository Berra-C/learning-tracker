# Backend change request (not applied)

**Status: review required.** Public Productivity App source was unavailable from this session, so this is a non-destructive proposed integration patch rather than a verified deployed change.

## New resources

- `public.learning_tracker_states`: keyed by the existing `app_accounts.id` (type inferred dynamically), `jsonb state`, revision and timestamp.
- `public.learning_tracker_state_cas()`: atomic revision check and insert/update, service-role-only.
- Two additive action handlers: `learning-tracker-sync-pull`, `learning-tracker-sync-push`.

## Existing resources left unchanged

- `app_accounts`, `app_sessions`, `app_states`, all credential verification/hashing, session rules, `signup`, `login`, `me`, `logout`, device actions, existing productivity sync and rate limits.

## Isolation and authorization

The existing authenticated Edge Function obtains the account ID from the existing verified session, then calls `handleLearningTrackerAction`. Client account IDs are deliberately ignored. Anonymous direct access to the table/RPC is revoked. The state table is separate from Productivity App's data.

## Migration prerequisites

`public.app_accounts(id)` must exist with suitable privileges and stable FK type. Verify that your deployed database schema and service role settings match these assumptions. The SQL dynamic type inference is designed to avoid guessing UUID versus integer.

## Verification checklist

- Valid session pull and push for two distinct existing accounts never cross boundaries.
- Token expiration, logout and revocation prevent later pulls/pushes.
- Registration in either application works in both, using the exact same account.
- Two devices with the same expected revision produce one success and one 409 conflict.
- Runtime payload validation rejects malformed states and oversized input.
- No regression in Productivity App state retrieval or mutation.
- Site deployment loads under shared Pages origin, and authenticated CORS works.

No deployment, migration, merge, or real-user integration has been performed.
