'use strict';
const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process');
const root=path.resolve(__dirname,'..'),manifest=require('./module-manifest');
const parts=['/* Generated from source modules. Do not edit app.js directly. */\n'];
for(const file of manifest){const full=path.join(root,file);if(!fs.existsSync(full))throw Error('Missing module '+file);cp.execFileSync(process.execPath,['--check',full],{stdio:'pipe'});parts.push(`\n/* SOURCE: ${file} */\n`+fs.readFileSync(full,'utf8')+'\n');}
const dest=path.join(root,'assets/js/app.js');fs.writeFileSync(dest,parts.join('\n'));
cp.execFileSync(process.execPath,['--check',dest],{stdio:'inherit'});console.log('Bundled '+manifest.length+' source modules to assets/js/app.js');
