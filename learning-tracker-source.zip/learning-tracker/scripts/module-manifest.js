module.exports = [
  'assets/js/modules/core.js',
  'assets/js/modules/importer.js',
  'assets/js/modules/planning.js',
  'assets/js/modules/sync.js',
  'assets/js/modules/cloud.js',
  'assets/js/app-main.js'
];
