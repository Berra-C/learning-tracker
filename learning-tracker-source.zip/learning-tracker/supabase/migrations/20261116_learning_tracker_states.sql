-- Additive migration; does not alter app_accounts, app_states, or existing API contracts.
-- Derives the account ID datatype from the deployed app_accounts table.
DO $migration$
DECLARE id_type text;
BEGIN
  SELECT pg_catalog.format_type(a.atttypid, a.atttypmod)
    INTO id_type
    FROM pg_catalog.pg_attribute a
   WHERE a.attrelid='public.app_accounts'::regclass
     AND a.attname='id' AND NOT a.attisdropped;
  IF id_type IS NULL THEN RAISE EXCEPTION 'Cannot find public.app_accounts.id'; END IF;
  EXECUTE format($ddl$
    CREATE TABLE IF NOT EXISTS public.learning_tracker_states (
      account_id %s PRIMARY KEY REFERENCES public.app_accounts(id) ON DELETE CASCADE,
      state jsonb NOT NULL DEFAULT '{}'::jsonb,
      revision bigint NOT NULL DEFAULT 0 CHECK (revision >= 0),
      updated_at timestamptz NOT NULL DEFAULT now()
    )$ddl$, id_type);
END;
$migration$;

ALTER TABLE public.learning_tracker_states ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.learning_tracker_states FROM PUBLIC, anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.learning_tracker_states TO service_role;

-- Atomic compare-and-swap: callers must be authenticated by the EXISTING Edge Function.
-- Never expose this RPC to browser clients. A verified account ID comes from app_sessions.
CREATE OR REPLACE FUNCTION public.learning_tracker_state_cas(
  p_account_id text,
  p_expected_revision bigint,
  p_state jsonb
) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER
SET search_path = ''
AS $func$
DECLARE current_revision bigint; new_revision bigint; inserted_count integer;
BEGIN
  IF p_account_id IS NULL OR length(p_account_id) > 200 OR p_expected_revision < 0 THEN
    RAISE EXCEPTION 'Invalid account or revision';
  END IF;
  IF p_state IS NULL OR jsonb_typeof(p_state) <> 'object'
     OR p_state->>'schemaVersion' <> '1'
     OR octet_length(p_state::text) > 8000000 THEN
    RAISE EXCEPTION 'Invalid Learning Tracker state';
  END IF;
  SELECT revision INTO current_revision
    FROM public.learning_tracker_states
   WHERE account_id::text=p_account_id FOR UPDATE;
  IF NOT FOUND THEN
    IF p_expected_revision <> 0 THEN
      RETURN jsonb_build_object('conflict',true,'revision',0);
    END IF;
    INSERT INTO public.learning_tracker_states(account_id,state,revision,updated_at)
      SELECT id,p_state,1,now() FROM public.app_accounts
       WHERE id::text=p_account_id
    ON CONFLICT(account_id) DO NOTHING;
    GET DIAGNOSTICS inserted_count = ROW_COUNT;
    IF inserted_count = 0 THEN
      SELECT revision INTO current_revision FROM public.learning_tracker_states
       WHERE account_id::text=p_account_id;
      IF current_revision IS NULL THEN RAISE EXCEPTION 'Account not found'; END IF;
      RETURN jsonb_build_object('conflict',true,'revision',current_revision);
    END IF;
    RETURN jsonb_build_object('conflict',false,'revision',1);
  END IF;
  IF current_revision <> p_expected_revision THEN
    RETURN jsonb_build_object('conflict',true,'revision',current_revision);
  END IF;
  UPDATE public.learning_tracker_states
     SET state=p_state, revision=revision+1, updated_at=now()
   WHERE account_id::text=p_account_id
   RETURNING revision INTO new_revision;
  RETURN jsonb_build_object('conflict',false,'revision',new_revision);
END;
$func$;
REVOKE ALL ON FUNCTION public.learning_tracker_state_cas(text,bigint,jsonb) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.learning_tracker_state_cas(text,bigint,jsonb) TO service_role;
