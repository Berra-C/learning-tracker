/**
 * Additive patch for EXISTING Productivity App app-api Edge Function.
 * Do not expose as a separately callable unauthenticated function.
 * Invoke ONLY AFTER existing session-validation logic returns a verified account ID.
 * We could not inspect that repository in this environment; adapt its actual
 * auth helper/action switch and response contract before production rollout.
 */
interface SupabaseServiceClient {
  from(table: string): any;
  rpc(name: string, args: Record<string,unknown>): Promise<{data:any;error:any}>;
}
export type VerifiedLearningTrackerContext = {
  /** ID issued by EXISTING app-api session verifier, never from request JSON. */
  verifiedAccountId: string;
  serviceClient: SupabaseServiceClient;
};
const KEY_NAMES = ["courses","resources","nodes","progress","events","assignments","reviews","weekNotes"] as const;
function validatePayload(input: unknown): asserts input is Record<string, unknown> {
  if (!input || typeof input !== "object" || Array.isArray(input)) throw new Error("Invalid state");
  const state = input as Record<string,unknown>;
  if (state.schemaVersion !== 1 || !state.settings || typeof state.settings !== "object" || Array.isArray(state.settings)) throw new Error("Invalid schema version/settings");
  let count = 0;
  for (const name of KEY_NAMES) {
    const arr = state[name];
    if (!Array.isArray(arr) || arr.length > 150000) throw new Error(`Invalid ${name}`);
    const ids = new Set<string>();
    for (const record of arr) {
      count++;
      if (!record || typeof record !== "object" || typeof record.id !== "string" || record.id.length > 180 || ids.has(record.id)) throw new Error(`Invalid ${name} record`);
      ids.add(record.id);
    }
  }
  if (count > 150000) throw new Error("Too many state records");
  if (JSON.stringify(input).length > 8_000_000) throw new Error("State is too large");
}
export async function handleLearningTrackerAction(
 action: string, body: Record<string,unknown>, context: VerifiedLearningTrackerContext
): Promise<{status: number; body: Record<string,unknown>}> {
 const {verifiedAccountId,serviceClient}=context;
 if (!verifiedAccountId) return {status:401,body:{error:"Session required"}};
 if (action === "learning-tracker-sync-pull") {
   const {data,error}=await serviceClient.from("learning_tracker_states")
     .select("state,revision").eq("account_id",verifiedAccountId).maybeSingle();
   if(error) return {status:500,body:{error:"Storage read failed"}};
   return {status:200,body:{state:data?.state||null,revision:data?.revision||0}};
 }
 if (action === "learning-tracker-sync-push") {
   try { validatePayload(body.state); }catch(e){return {status:400,body:{error:(e as Error).message}}}
   const expectedRevision=body.expectedRevision;
   if(!Number.isSafeInteger(expectedRevision)||Number(expectedRevision)<0) return{status:400,body:{error:"Invalid expectedRevision"}};
   const {data,error}=await serviceClient.rpc("learning_tracker_state_cas",{
      p_account_id:verifiedAccountId,
      p_expected_revision:expectedRevision,
      p_state:body.state
   });
   if(error) return {status:500,body:{error:"Storage write failed"}};
   if(data?.conflict) return {status:409,body:{error:"Revision conflict",code:"revision_conflict",revision:data.revision}};
   return {status:200,body:{revision:data?.revision}};
 }
 return {status:404,body:{error:"Unknown Learning Tracker operation"}};
}

/** Integration placement example (PSEUDOCODE, adapt to actual index.ts):
 *  if (action === 'learning-tracker-sync-pull' || action === 'learning-tracker-sync-push') {
 *    const account = await verifyExistingSession(requestSessionToken); // REAL existing helper
 *    if (!account) return respond(401, {error:'Unauthorized'});
 *    const result = await handleLearningTrackerAction(action, body, {
 *      verifiedAccountId: String(account.id), serviceClient: existingServiceRoleClient
 *    });
 *    return respond(result.status, result.body);
 *  }
 * Do NOT create a new identity system or let the client pass verifiedAccountId.
 */
