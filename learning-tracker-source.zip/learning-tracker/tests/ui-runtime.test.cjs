const {test}=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const vm=require('node:vm');const path=require('node:path');
const root=path.resolve(__dirname,'..');
test('browser application bootstraps without shared backend and displays an empty local workspace',async()=>{
 const nodes=new Map(),listeners=new Map();
 function el(selector){if(!nodes.has(selector)){const set=new Set(),events=new Map();nodes.set(selector,{dataset:{},style:{},textContent:'',innerHTML:'',hidden:false,classList:{add(x){set.add(x)},remove(x){set.delete(x)},contains(x){return set.has(x)},toggle(x,yes){if(yes===undefined? !set.has(x):yes)set.add(x);else set.delete(x)}},addEventListener(name,callback){events.set(name,callback)},_events:events,setAttribute(){},value:''})}return nodes.get(selector)}
 const storage=new Map(),store={getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,String(v)),removeItem:k=>storage.delete(k)};
 const doc={documentElement:{dataset:{}},querySelector:el,querySelectorAll(){return[]},addEventListener(name,fn){listeners.set(name,fn)}};
 const context=vm.createContext({document:doc,localStorage:store,sessionStorage:store,window:{localStorage:store,sessionStorage:store,scrollTo(){},addEventListener(){}},console,Date,Math,JSON,Set,Map,Error,Number,String,Array,Object,Intl,RegExp,crypto:require('node:crypto').webcrypto,setTimeout,clearTimeout,confirm:()=>true});context.globalThis=context;context.LT_CLOUD_CONFIG={};
 vm.runInContext(fs.readFileSync(path.join(root,'assets/js/app.js'),'utf8'),context);
 assert.match(el('#authStatus').textContent,/Bulut bağlantısı/);
 await el('#demoBtn')._events.get('click')();await new Promise(resolve=>setTimeout(resolve,30));
 assert.match(el('#mainContent').innerHTML,/Genel Bakış/);
 assert.match(el('#mainContent').innerHTML,/Henüz ders yok/);
 assert.match(el('#syncStatus').textContent,/Yerel deneme/);
 assert.equal(el('#authGate').classList.contains('hidden'),true);
});
test('UI controller handles local course → resource → topic → completion → weekly plan lifecycle',async()=>{
 const nodes=new Map(),listeners=new Map();
 function el(selector){if(!nodes.has(selector)){const classes=new Set(),events=new Map();nodes.set(selector,{dataset:{},style:{},textContent:'',innerHTML:'',hidden:false,classList:{add:x=>classes.add(x),remove:x=>classes.delete(x),contains:x=>classes.has(x),toggle(x,on){if(on===undefined?!classes.has(x):on)classes.add(x);else classes.delete(x)}},addEventListener(name,callback){events.set(name,callback)},_events:events,setAttribute(){},value:''})}return nodes.get(selector)}
 const storage=new Map(),store={getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,String(v)),removeItem:k=>storage.delete(k)};
 const doc={documentElement:{dataset:{}},querySelector:el,querySelectorAll(){return[]},addEventListener(name,fn){listeners.set(name,fn)}};
 const context=vm.createContext({document:doc,localStorage:store,sessionStorage:store,window:{localStorage:store,sessionStorage:store,scrollTo(){},addEventListener(){}},console,Date,Math,JSON,Set,Map,Error,Number,String,Array,Object,Intl,RegExp,crypto:require('node:crypto').webcrypto,setTimeout,clearTimeout,confirm:()=>true,FormData:function(form){return Object.entries(form.values)}});context.globalThis=context;context.LT_CLOUD_CONFIG={};
 vm.runInContext(fs.readFileSync(path.join(root,'assets/js/app.js'),'utf8'),context);
 await el('#demoBtn')._events.get('click')();await new Promise(resolve=>setTimeout(resolve,15));
 const click=(dataset)=>{const target={dataset,closest(){return this}};listeners.get('click')({target,preventDefault(){},stopPropagation(){}})};
 const submit=(kind,values,id='',more={})=>listeners.get('submit')({target:{id:'recordForm',dataset:{kind,id,...more},values},preventDefault(){}});
 click({action:'add-course'});assert.match(el('#modalBody').innerHTML,/Ders adı/);
 submit('course',{name:'Biology',category:'school',color:'#159e89'});
 assert.match(el('#mainContent').innerHTML,/Biology/);
 const courseId=el('#sideCourses').innerHTML.match(/data-course="([^"]+)"/)[1];
 click({action:'add-resource'});
 submit('resource',{title:'Biology Textbook',type:'book',courseId,sourceUrl:''});
 assert.match(el('#mainContent').innerHTML,/Biology Textbook/);
 const resourceId=el('#mainContent').innerHTML.match(/data-resource="([^"]+)"/)[1];
 click({action:'add-node'});submit('node',{title:'Cell membrane',kind:'topic'},'',{resource:resourceId,parent:''});
 assert.match(el('#mainContent').innerHTML,/Cell membrane/);
 const nodeId=el('#mainContent').innerHTML.match(/data-action="toggle-node" data-id="([^"]+)"/)[1];
 click({action:'toggle-node',id:nodeId});click({action:'toggle-node',id:nodeId});
 assert.match(el('#mainContent').innerHTML,/100% tamamlandı/);
 click({action:'plan-mode'});click({action:'toggle-node',id:nodeId});
 el('#planTargetWeek').value=context.LT.core.monday();
 click({action:'assign-selected'});click({page:'weekly'});
 assert.match(el('#mainContent').innerHTML,/Cell membrane/);
 click({page:'analytics'});assert.match(el('#mainContent').innerHTML,/İstatistikler/);
 click({page:'settings'});assert.match(el('#mainContent').innerHTML,/Yedekleme/);
});
